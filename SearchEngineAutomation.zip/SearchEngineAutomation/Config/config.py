"""This file contains a class of basic configs for all pages"""

class TestData:
    ChromeExecutablePath = "C:\\chromedriver.exe"  # Location of Chrome driver
    FirefoxExecutablePath = "C:\\geckodriver.exe"  # Location of Firefox driver
    Base_URL = "https://www.google.com/"  # Base URL for test site
    PageTitle = "Google"  # Title for Google search page
    SearchText = "Matic Network"  # Text used to perform google search
    SearchText_SmallCase = "matic network"  # Small case text to perform google search
    ResultText = "Matic Network - Scalable and instant blockchain transactions"  # Result text after google search
